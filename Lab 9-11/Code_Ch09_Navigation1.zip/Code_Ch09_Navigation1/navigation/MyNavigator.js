import { createStackNavigator } from "react-navigation-stack";
import { createAppContainer } from "react-navigation";

import Screen1 from "../screens/Screen1";
import Screen2 from "../screens/Screen2";
import Screen3 from "../screens/Screen3";

const MyNavigator = createStackNavigator(
  {
    S1: {
      screen: Screen1,
      navigationOptions: {
        title: "Screen 1",
      },
    },
    S2: { screen: Screen2 },
    S3: { screen: Screen3 },
  },
  {
    defaultNavigationOptions: {
      headerStyle: { backgroundColor: "lightblue" },
    },
  }
);

export default createAppContainer(MyNavigator);
