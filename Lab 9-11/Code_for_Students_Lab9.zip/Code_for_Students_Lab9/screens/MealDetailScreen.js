import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { MEALS } from "../data/dummy-data";

const MealDetailScreen = (props) => {
  // เขียนโค้ดเพิ่ม เพื่อดึงอ็อบเจ๊คเมนูอาหารที่ผู้ใช้เลือกเอาไว้

  return (
    <View style={styles.screen}>
      <Text>The Meal Detail Screen!</Text>
      <Text>...เขียนโค้ดเพิ่มแสดงชื่อเมนูอาหารที่เลือก...</Text>
      <Text>...เขียนโค้ดเพิ่มแสดงวิธีทำอาหารของเมนูที่เลือก...</Text>
      <Button
        title="Go Back to Categories"
        onPress={() => {
          // เขียนโค้ดเพิ่ม
        }}
      />
    </View>
  );
};

// MealDetailScreen.navigationOptions = (navigationData) => {
//   // เขียนโค้ดเพิ่มเพื่อแสดงชื่อเมนูอาหารที่เลือกให้เป็นเฮดเดอร์
// };

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default MealDetailScreen;
