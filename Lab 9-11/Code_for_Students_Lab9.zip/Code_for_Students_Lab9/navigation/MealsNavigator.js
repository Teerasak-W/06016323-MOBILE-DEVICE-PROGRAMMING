// import คอมโพเนนต์ที่จำเป็น

const MealsNavigator = createStackNavigator(
  {
    // กำหนด RouteConfigs (Slide 14)
  },
  {
    // กำหนด defaultNavigationOptions (Slide 23-24)
  }
);

export default createAppContainer(MealsNavigator);
