import { createBottomTabNavigator } from "react-navigation-tabs";
import { createAppContainer } from "react-navigation";

import Tab1 from "../screens/Tab1";
import Tab2 from "../screens/Tab2";
import Tab3 from "../screens/Tab3";

const MyTabNavigator = createBottomTabNavigator(
  {
    Tab_1: { screen: Tab1 },
    Tab_2: { screen: Tab2 },
    Tab_3: { screen: Tab3 },
  },
  {
    tabBarOptions: {
      activeTintColor: "darkblue",
      labelStyle: {
        fontSize: 18,
      },
      style: {
        backgroundColor: "lightblue",
      },
    },
  }
);

export default createAppContainer(MyTabNavigator);
